-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         11.0.1-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para renta_instrumentosm
CREATE DATABASE IF NOT EXISTS `renta_instrumentosm` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `renta_instrumentosm`;

-- Volcando estructura para tabla renta_instrumentosm.alquiler
CREATE TABLE IF NOT EXISTS `alquiler` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`,`username`,`fecha`) USING BTREE,
  KEY `FK_usuarios` (`username`),
  CONSTRAINT `FK_instrumentos` FOREIGN KEY (`id`) REFERENCES `instrumentos` (`id`),
  CONSTRAINT `FK_usuarios` FOREIGN KEY (`username`) REFERENCES `usuarios` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla renta_instrumentosm.alquiler: ~0 rows (aproximadamente)

-- Volcando estructura para tabla renta_instrumentosm.instrumentos
CREATE TABLE IF NOT EXISTS `instrumentos` (
  `id` int(11) NOT NULL,
  `NomInst` varchar(100) DEFAULT NULL,
  `TipInst` varchar(100) DEFAULT NULL,
  `MarcInst` varchar(100) DEFAULT NULL,
  `CantInst` int(11) DEFAULT NULL,
  `Novedad` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla renta_instrumentosm.instrumentos: ~18 rows (aproximadamente)
INSERT INTO `instrumentos` (`id`, `NomInst`, `TipInst`, `MarcInst`, `CantInst`, `Novedad`) VALUES
	(1, 'Guitarra Electrica', 'Cuerda', 'Gibson Les Paul', 5, 0),
	(2, 'Guitarra Electrica', 'Cuerda', 'Martin', 5, 0),
	(3, 'Guitarra Electroacustica', 'Cuerda', 'Taylor', 5, 0),
	(4, 'Guitarra Electroacustica', 'Cuerda', 'Takamine', 5, 1),
	(5, 'Guitarra Electrica', 'Cuerda', 'Boss', 5, 0),
	(6, 'Guitarra Electroacustica', 'Cuerda', 'Andalucia', 5, 0),
	(7, 'Guitarra Electrica', 'Cuerda', 'Epiphone', 5, 0),
	(8, 'Guitarra Electrica', 'Cuerda', 'Fender', 5, 0),
	(9, 'Guitarra Electrica', 'Cuerda', 'Ibanez', 5, 0),
	(10, 'Guitarra Electrica', 'Cuerda', 'Yamaha', 5, 0),
	(11, 'Guitarra Electrica', 'Cuerda', 'Gretsch', 5, 0),
	(12, 'Bajo Electrico', 'Cuerda', 'Yamaha', 5, 0),
	(13, 'Bajo Electrico', 'Cuerda', 'Ibanez', 5, 0),
	(14, 'Bateria', 'Percusion', 'Yamaha', 5, 0),
	(15, 'Bateria', 'Percusion', 'Tama', 5, 0),
	(16, 'Bateria', 'Percusion', 'Mapex', 5, 0),
	(17, 'saxofon alto', 'Viento', 'SML', 5, 0),
	(18, 'Guitarra Electrica', 'Cuerda', 'Yamaha', 5, 0);

-- Volcando estructura para tabla renta_instrumentosm.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `username` varchar(100) NOT NULL,
  `contrasena` varchar(100) DEFAULT NULL,
  `nombres` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `saldo` double(22,2) DEFAULT NULL,
  `premium` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Volcando datos para la tabla renta_instrumentosm.usuarios: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

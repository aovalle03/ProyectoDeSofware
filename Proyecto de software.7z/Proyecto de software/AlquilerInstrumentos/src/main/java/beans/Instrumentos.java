/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author andyf
 */
public class Instrumentos {
    
    private int id;
    private String NomInst;
    private String TipInst;
    private String MarcInst;
    private int CantInst;
    private boolean Novedad;

    public Instrumentos(int id, String NomInst, String TipInst, String MarcInst, int CantInst, boolean Novedad) {
        this.id = id;
        this.NomInst = NomInst;
        this.TipInst = TipInst;
        this.MarcInst = MarcInst;
        this.CantInst = CantInst;
        this.Novedad = Novedad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomInst() {
        return NomInst;
    }

    public void setNomInst(String NomInst) {
        this.NomInst = NomInst;
    }

    public String getTipInst() {
        return TipInst;
    }

    public void setTipInst(String TipInst) {
        this.TipInst = TipInst;
    }

    public String getMarcInst() {
        return MarcInst;
    }

    public void setMarcInst(String MarcInst) {
        this.MarcInst = MarcInst;
    }

    public int getCantInst() {
        return CantInst;
    }

    public void setCantInst(int CantInst) {
        this.CantInst = CantInst;
    }

    public boolean isNovedad() {
        return Novedad;
    }

    public void setNovedad(boolean Novedad) {
        this.Novedad = Novedad;
    }

    @Override
    public String toString() {
        return "Instrumentos{" + "id=" + id + ", NomInst=" + NomInst + ", TipInst=" + TipInst + ", MarcInst=" + MarcInst + ", CantInst=" + CantInst + ", Novedad=" + Novedad + '}';
    }
    
    
    
}
